import pickle
import numpy as np
import streamlit as st
from streamlit_option_menu import option_menu

# Loading the saved models
heart_disease_model = pickle.load(open(r'C:\Users\Acer\OneDrive\Desktop\multiple disease prediction\trained_heart_disease_model.sav', 'rb'))
diabetes_model = pickle.load(open(r'C:\Users\Acer\OneDrive\Desktop\multiple disease prediction\trained_diabeties_model.sav', 'rb'))

# Sidebar for navigation
with st.sidebar:
    selected = option_menu('Disease Prediction System',
                           ['Home', 'Heart Failure Prediction', 'Diabetes Prediction'],
                           default_index=0)

# Home page
if selected == 'Home':
    st.title('Welcome to Disease prediction System ')
    st.write("""
        This application helps in predicting the likelihood of various diseases based on user input data.
        \nSelect a prediction option from the sidebar to get started.
        \nThe available options are:
        - **Heart Failure Prediction**
        - **Diabetes Prediction**
        \nMake sure to enter accurate data to get the best predictions.
    """)
    st.image("C:/Users/Acer/OneDrive/Desktop/multiple disease prediction/health-medical-healthcare-health.jpg", use_column_width=True)

# Heart Failure Prediction Page
elif selected == 'Heart Failure Prediction':
    st.title('Heart Failure Prediction')

    col1, col2 = st.columns(2)

    with col1:
        age = st.number_input('Age', min_value=0)
        sex = st.selectbox('Sex', ['M', 'F'])
        chest_pain_type = st.selectbox('Chest Pain Type', ['ATA', 'NAP', 'ASY', 'TA'])
        resting_bp = st.number_input('Resting Blood Pressure', min_value=0)
        cholesterol = st.number_input('Cholesterol', min_value=0)
        fasting_bs = st.selectbox('Fasting Blood Sugar > 120 mg/dl', ['Yes', 'No'])

    with col2:
        resting_ecg = st.selectbox('Resting ECG', ['Normal', 'ST', 'LVH'])
        max_hr = st.number_input('Maximum Heart Rate Achieved', min_value=0)
        exercise_angina = st.selectbox('Exercise Induced Angina', ['Y', 'N'])
        oldpeak = st.number_input('Oldpeak', min_value=0.0, format="%.1f")
        st_slope = st.selectbox('ST Slope', ['Up', 'Flat', 'Down'])

    # Convert categorical data to numerical values
    sex = 1 if sex == 'M' else 0
    chest_pain_type_mapping = {'ATA': 0, 'NAP': 1, 'ASY': 2, 'TA': 3}
    chest_pain_type = chest_pain_type_mapping[chest_pain_type]

    fasting_bs = 1 if fasting_bs == 'Yes' else 0

    resting_ecg_mapping = {'Normal': 0, 'ST': 1, 'LVH': 2}
    resting_ecg = resting_ecg_mapping[resting_ecg]

    exercise_angina = 1 if exercise_angina == 'Y' else 0

    st_slope_mapping = {'Up': 0, 'Flat': 1, 'Down': 2}
    st_slope = st_slope_mapping[st_slope]

    # Prediction logic
    if st.button('Predict Heart Failure'):
        input_data = [[age, sex, chest_pain_type, resting_bp, cholesterol, fasting_bs,
                       resting_ecg, max_hr, exercise_angina, oldpeak, st_slope]]

        prediction = heart_disease_model.predict(input_data)

        if prediction[0] == 1:
            st.error('The patient is likely to have heart failure.')
        else:
            st.success('The patient is not likely to have heart failure.')

# Diabetes Prediction Page
elif selected == 'Diabetes Prediction':
    st.title('Diabetes Prediction')
    st.write("""
        This section allows you to input your health data to predict the likelihood of diabetes.
        \nPlease provide accurate values for each of the following health metrics.
    """)

    col1, col2 = st.columns(2)

    with col1:
        pregnancies = st.number_input('Pregnancies', min_value=0, max_value=20, step=1)
        glucose = st.number_input('Glucose Level', min_value=0, max_value=300, step=1)
        blood_pressure = st.number_input('Blood Pressure (mm Hg)', min_value=0, max_value=200, step=1)
        skin_thickness = st.number_input('Skin Thickness (mm)', min_value=0, max_value=100, step=1)

    with col2:
        insulin = st.number_input('Insulin Level (mu U/ml)', min_value=0, max_value=900, step=1)
        bmi = st.number_input('BMI (Body Mass Index)', min_value=0.0, max_value=70.0, step=0.1)
        diabetes_pedigree_function = st.number_input('Diabetes Pedigree Function', min_value=0.0, max_value=2.5, step=0.01)
        age = st.number_input('Age', min_value=0, max_value=120, step=1)

    # Prediction logic
    if st.button('Predict Diabetes'):
        input_data = np.array([[pregnancies, glucose, blood_pressure, skin_thickness, insulin,
                                bmi, diabetes_pedigree_function, age]])

        prediction = diabetes_model.predict(input_data)

        if prediction[0] == 0:
            st.error('The patient is likely to have diabetes.')
        else:
            st.success('The patient is not likely to have diabetes.')
