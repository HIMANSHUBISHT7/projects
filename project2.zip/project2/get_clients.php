<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lawyer_recommendation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'] ?? '';
$role = $_POST['role'] ?? '';
$location = $_POST['location'] ?? '';

if (empty($name) || empty($role) || empty($location)) {
    die("All fields are required.");
}

if ($role === 'Lawyer') {
    $specialization = $_POST['specialization'] ?? '';
    $experience = $_POST['experience'] ?? 0;
    $price_range = $_POST['price_range'] ?? '';

    if (empty($specialization) || empty($price_range)) {
        die("All lawyer fields are required.");
    }

    $stmt = $conn->prepare("INSERT INTO lawyers (name, specialization, experience, price_range, location) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiss", $name, $specialization, $experience, $price_range, $location);

} else {
    $case_type = $_POST['case_type'] ?? '';
    $budget_range = $_POST['budget_range'] ?? '';

    if (empty($case_type) || empty($budget_range)) {
        die("All client fields are required.");
    }

    $stmt = $conn->prepare("INSERT INTO clients (name, case_type, budget_range, location) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $case_type, $budget_range, $location);
}

if ($stmt->execute()) {
    echo "Registration successful!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
