<?php
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database_name";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$case_type = $_GET['case_type'];
$budget_range = $_GET['budget_range'];

$sql = "SELECT * FROM clients WHERE case_type = '$case_type' AND budget_range = '$budget_range'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Results</title>
    <style>
        /* Use the same CSS from your previous styles */
    </style>
</head>
<body>

    <div class="container">
        <h1>Client Search Results</h1>
        <div id="results">
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<p><strong>Name:</strong> " . $row["name"] . "<br>";
                    echo "<strong>Case Type:</strong> " . $row["case_type"] . "<br>";
                    echo "<strong>Budget Range:</strong> " . $row["budget_range"] . "<br>";
                    echo "<strong>Location:</strong> " . $row["location"] . "</p><hr>";
                }
            } else {
                echo "<p>No clients found for your criteria.</p>";
            }
            $conn->close();
            ?>
        </div>
    </div>

</body>
</html>
