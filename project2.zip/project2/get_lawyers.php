<?php
include 'connect.php';

// Get the POST data
$case_type = $_POST['case_type'];
$budget_range = $_POST['budget_range'];

// Prepare and execute the SQL query
$sql = "SELECT Users.name, Lawyers.experience, Lawyers.price_range, Users.location 
        FROM Lawyers
        JOIN Users ON Lawyers.id = Users.id
        WHERE Lawyers.specialization = '$case_type' AND Lawyers.price_range = '$budget_range'";

$result = $conn->query($sql);

// Fetch the results and encode them as JSON
$matchedLawyers = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $matchedLawyers[] = $row;
    }
}

// Return the results in JSON format
echo json_encode($matchedLawyers);

$conn->close();
?>
