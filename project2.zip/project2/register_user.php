<!-- <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lawyer_recommendation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$role = $_POST['role'];
$location = $_POST['location'];

if ($role === 'Lawyer') {
    $specialization = $_POST['specialization'];
    $experience = $_POST['experience'];
    $price_range = $_POST['price_range'];

    $sql = "INSERT INTO lawyers (name, specialization, experience, price_range, location)
            VALUES ('$name', '$specialization', '$experience', '$price_range', '$location')";
} else {
    $case_type = $_POST['case_type'];
    $budget_range = $_POST['budget_range'];

    $sql = "INSERT INTO clients (name, case_type, budget_range, location)
            VALUES ('$name', '$case_type', '$budget_range', '$location')";
}

if ($conn->query($sql) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?> -->

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lawyer_recommendation";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$role = $_POST['role'];
$location = $_POST['location'];

if ($role === 'Lawyer') {
    $specialization = $_POST['specialization'];
    $experience = $_POST['experience'];
    $price_range = $_POST['price_range'];

    $sql = "INSERT INTO lawyers (name, specialization, experience, price_range, location)
            VALUES ('$name', '$specialization', '$experience', '$price_range', '$location')";
} else {
    $case_type = $_POST['case_type'];
    $budget_range = $_POST['budget_range'];

    $sql = "INSERT INTO clients (name, case_type, budget_range, location)
            VALUES ('$name', '$case_type', '$budget_range', '$location')";
}

if ($conn->query($sql) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

